import Test.HUnit
import TP


data Desconocido = ResultadoDeTipoDesconocido

--
-- correr todo usando:
-- > correrTodo
--

-- DATOS PARA ARMAR LAS PRUEBAS (modificar donde corresponda)
-- Cada una de estas funciones debe retornar una tupla de aridad 3
-- cuyos valores representan (descripcion, consulta que resuelve lo pedido, resultado esperado)
-- por cuestiones de tipado, cambien los ResultadoDeTipoDesconocido para una misma función de datos de test (por ejemplo datosTest3) todos juntos
-- pueden reemplazar los undefined por la consulta que resuelve el problema por separado sin problemas porque undefined :: a


datosTest3 1 = ("Cristian debe estar duro", comoEsta cristian, "Duro")
datosTest3 2 = ("Rodri debe estar fresco", comoEsta rodri, "Fresco")
datosTest3 3 = ("Marcos debe estar duro", comoEsta marcos, "Duro")
datosTest3 4 = ("Si Marcos se hace amigo de Ana y Rodri, está piola", (comoEsta . agregarAmigo ana) marcos, "Piola")

datosTest4 1 = ("Rodri intenta hacerse amigo de sí mismo", agregarAmigo rodri rodri, rodri)

datosTest4 2 = ("Marcos intenta hacerse amigo de Rodri, de quien ya es amigo", agregarAmigo rodri marcos, marcos)
datosTest4 3 = ("Rodri intenta hacerse amigo de Marcos, que no era su amigo", agregarAmigo marcos rodri, cambiarAmigos [marcos] rodri)

datosTest5 1 = ("Si Ana toma GrogXD queda con resistencia 0", grogXD ana, restarResistencia 120 ana)

datosTest5 2 = ("Si Ana toma la Jarra Loca su resistencia y la de sus amigos baja", jarraLoca ana, (restarResistencia 10  . (flip cambiarAmigos) ana . map (restarResistencia 10) . amigos) ana) 

datosTest5 3 = ("Si Ana toma un Klusener de huevo queda con resistencia 115", klusener "huevo" ana, restarResistencia 5 ana)

datosTest5 4 = ("Si Ana toma un Klusener de chocolate queda con resistencia 111", klusener "chocolate" ana, restarResistencia 9 ana)
datosTest5 5 = ("Si Cristian toma un Tintico queda con resistencia 2", tintico cristian, restarResistencia 0 cristian)

datosTest5 6 = ("Si Ana toma un Tintico queda con resistencia 130", tintico ana, (restarResistencia ((length (amigos ana)) * (-5))) ana)

datosTest5 7 = ("Si Rodri toma una Soda de fuerza 2 queda con nombre errpRodri", soda 2 rodri, cambiarNombre "errpRodri" rodri)

datosTest5 8 = ("Si Ana toma una Soda de fuerza 10 queda con nombre errrrrrrrrrpAna", soda 10 ana, cambiarNombre "errrrrrrrrrpAna" ana)

datosTest5 9 = ("Si Ana toma una Soda de fuerza 0 queda con nombre epAna", soda 0 ana, cambiarNombre "epAna" ana)

datosTest6 1 = ("Si Rodri se rescata 5 horas queda con 255 de resistencia", rescatarse 5 rodri, restarResistencia (-200) rodri)
datosTest6 2 = ("Si Rodri se rescata 1 hora queda con 155 de resistencia", rescatarse 1 rodri, restarResistencia (-100) rodri)

datosTest7 1 = ("Itinerario de Ana", itinerarioAna ana,  (restarResistencia (-76) . (flip cambiarAmigos) ana . map (restarResistencia 10) . amigos) ana)


--- ENTREGA 2 ---
datosEntrega2Test1b 1 = ("Marcos toma una soda de nivel 3 y queda con 2 bebidas y con 40 de resistencia", tomar soda 3 marcos, (agregarBebida (soda 3) . cambiarNombre "errrpMarcos") marcos)

datosEntrega2Test1c 1 = ("Rodri toma una soda de nivel 1 y una soda de nivel 2 y queda con nombre errperpRodri", tomar soda 2 (tomar soda 1 rodri), (agregarBebida (soda 2).agregarBebida (soda 1).cambiarNombre ("errperpRodri"))rodri)

datosEntrega2Test1c 2 = ("Marcos toma un klusener de huevo, un tintico y una jarraLoca y queda con 30 de resistencia y con 4 bebidas en el historial" , tomarTragos marcos [klusener "huevo", tintico, jarraLoca] , (klusener "huevo" . tintico . jarraLoca) marcos)

datosEntrega2Test1d 1 = ("Marcos pide “dame otro” y queda con 2 bebidas en el historial y 34 de resistencia", dameOtro marcos , klusener "guinda" marcos)

datosEntrega2Test1d 2 = ("Rodri toma una soda de nivel 1, y “dame otro” da como resultado que tiene 3 bebidas y su nombre queda “erperpRodri”", (dameOtro . tomar (soda 1)) rodri, cambiarNombre "erperpRodri" rodri)

datosEntrega2Test2b 1 = ("Rodri puede tomar dos bebidas, entre un grog XD, un tintico y un klusener de frutilla", cuantasPuedeTomar rodri [grogXD, tintico, klusener "frutilla"], 2)

datosEntrega2Test2b 2 = ("Entre un grog XD, un tintico, un klusener de fruuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuutilla Rodri se puede tomar una sola bebida", cuantasPuedeTomar rodri [grogXD, tintico, klusener "fruuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuutilla"], 1)

datosEntrega2Test3b 1 = ("Rodri hace una salida de amigos... y le pasa de todo", tomarTragos rodri (bebidas salidaDeAmigos), (cambiarNombre "erpRodri" . agregarAmigo robertoCarlos . restarResistencia 5) rodri)

datosEntrega2Test4a 1 = ("la intensidad de la mezcla explosiva es 1.6", intensidad 1 mezclaExplosiva, 1.6)
datosEntrega2Test4a 2 = ("la intensidad de la salidaDeAmigos es 4.0", intensidad 1 salidaDeAmigos, 4.0)
datosEntrega2Test4a 3 = ("la intensidad del itinerario basico es 0.8", intensidad 1 itinerarioBasico, 0.8)

datosEntrega2Test4b 1 = ("Entre la salida de amigos, la mezcla explosiva y el itinerario básico, el itinerario más intenso es la salida de amigos", cualEsElMasIntenso [mezclaExplosiva, salidaDeAmigos, itinerarioBasico], salidaDeAmigos)

datosEntrega2Test4b 1 = ("Rodri hace el itinerario más intenso entre una salida de amigos, la mezcla explosiva y el itinerario básico y realiza salida de amigos", tomarElMasIntenso rodri [salidaDeAmigos,mezclaExplosiva,itinerarioBasico], tomarTragos rodri (bebidas salidaDeAmigos))

datosEntrega2Test6 1 = ("Roberto Carlos se hace amigo de Ana, toma una jarra popular de espirituosidad 0, sigue quedando con una sola amiga (Ana)", jarraPopular (agregarAmigo ana robertoCarlos) 0, agregarAmigo ana robertoCarlos)

datosEntrega2Test6 2 = ("Roberto Carlos se hace amigo de Ana, toma una jarra popular de espirituosidad 3, queda con 3 amigos (Ana, Marcos y Rodri)", jarraPopular (agregarAmigo ana robertoCarlos) 3, agregarAmigos robertoCarlos [ana, marcos, rodri])

datosEntrega2Test6 3 = ("Cristian se hace amigo de Ana. Roberto Carlos se hace amigo de Cristian, toma una jarra popular de espirituosidad 4, queda con 4 amigos (Cristian, Ana, Marcos y Rodri)", jarraPopular (agregarAmigo robertoCarlos (agregarAmigo cristian ana)) 4, agregarAmigos robertoCarlos [cristian, ana, marcos, rodri])

-- TESTS AUTOMATICOS (no modificar)

armarTest fDatosTest = (\(titulo, resultado, esperado) -> TestLabel titulo (resultado ~?= esperado)).fDatosTest

armarTestSuite titulo fDatosTest cant = (TestLabel titulo . TestList . map (armarTest fDatosTest)) [1.. cant]
tests = TestList [
    armarTestSuite "Punto 3" datosTest3 4,
    armarTestSuite "Punto 4" datosTest4 3,
    armarTestSuite "Punto 5" datosTest5 9,
    armarTestSuite "Punto 6" datosTest6 2,
    armarTestSuite "Punto 7" datosTest7 1,
    armarTestSuite "Entrega 2 Punto 1b" datosEntrega2Test1b 1,
    armarTestSuite "Entrega 2 Punto 1c" datosEntrega2Test1c 2,
    armarTestSuite "Entrega 2 Punto 1d" datosEntrega2Test1d 2,
    armarTestSuite "Entrega 2 Punto 2b" datosEntrega2Test2b 2,
    armarTestSuite "Entrega 2 Punto 3b" datosEntrega2Test3b 1,
    armarTestSuite "Entrega 2 Punto 4a" datosEntrega2Test4a 3,
    armarTestSuite "Entrega 2 Punto 4b" datosEntrega2Test4b 1,
    armarTestSuite "Entrega 2 Punto 4b" datosEntrega2Test4b 1,
    armarTestSuite "Entrega 2 Punto 6" datosEntrega2Test6 3
  ]
correrTodo = runTestTT tests