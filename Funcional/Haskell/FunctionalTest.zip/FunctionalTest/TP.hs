module TP where

-- Punto 1
-- Modelo del tipo de dato cliente.
-- Utilizamos un data porque nos genera automaticamente funciones para acceder a los valores del tipo definido, facilitando la composicion de funciones y la declaratividad en el codigo
data Cliente = Cliente {nombre:: String , resistencia::Int, amigos::[Cliente]} deriving(Show,Eq)

-- Punto 2
-- Modelelado de los amigos 
rodri = Cliente "Rodri" 55 []
marcos = Cliente "Marcos" 40 [rodri]
cristian = Cliente "Cristian" 2 []
ana = Cliente "Ana" 120 [marcos,rodri]

-- Punto 3
-- Desarrollo de la funcion comoEsta
comoEsta cliente | (resistencia cliente) > 50 = "Fresco" | (length (amigos cliente)) > 1 = "Piola" | otherwise = "Duro" 

-- Punto 4
-- funciones para reconocer y agregar amigos
soyYoMismo cli = (nombre cli==).nombre

esAmigo cli = (any (cli==)).amigos

puedoAgregarAmigo cli cliente = not(soyYoMismo cli cliente) && not(esAmigo cli cliente)

agregarAmigo cli cliente | puedoAgregarAmigo cli cliente = (Cliente (nombre cliente) (resistencia cliente) (cli:(amigos cliente))) | otherwise = cliente

-- Punto 5 
-- Representacion de las bebidas
grogXD cliente = Cliente (nombre cliente) 0 (amigos cliente)
jarraLoca cliente = Cliente (nombre cliente) ((resistencia cliente) - 10) (map jarraLoca (amigos cliente))
klusener sabor cliente = Cliente (nombre cliente) ((resistencia cliente) - length sabor) (amigos cliente)
tintico cliente = Cliente (nombre cliente) ((resistencia cliente) + length (amigos cliente) * 5) (amigos cliente)
soda fuerza cliente = Cliente ("e" ++ replicate fuerza 'r' ++ "p" ++ (nombre cliente)) (resistencia cliente) (amigos cliente)

-- Punto 6 
-- Hacer que un cliente pueda rescatarde
rescatarse horas cliente | horas > 3 = Cliente (nombre cliente) ((resistencia cliente) + 200) (amigos cliente) | otherwise = Cliente (nombre cliente) ((resistencia cliente) + 100) (amigos cliente)

-- Punto 7
-- La consulta de consola : nosotros la llamamos itinerarioAna
itinerarioAna = klusener "huevo".rescatarse 2.klusener "chocolate".jarraLoca



















